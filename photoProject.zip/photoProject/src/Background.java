import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Background extends JPanel {
    private double max;
    private static int minX = 0;
    private static int minY = 0;
    private static int maxX = 800;
    private static int maxY = 600;
    private boolean border;
    private static int point = 0;
    private Point[] points;
    private BufferedImage selectedImage;
    private JButton selectImageButton;
    private JButton negative;
    private JButton blackWhite;
    private JButton grayScale;
    private JButton shiftRight;
    private JButton shiftLeft;
    private JButton mirror;
    private JButton PixelAte;
    private JButton Darker;
    private JButton Lighter;

    private JFileChooser fileChooser;

    public Background(int x, int y, int width, int height) {
        this.setLayout(null);
        this.setBounds(x, y, width, height);
        this.setBackground(Color.cyan);

        selectImageButton = new JButton("Select image");
        selectImageButton.addActionListener(e -> selectImage());
        selectImageButton.setFocusable(false);
        selectImageButton.setBounds(615, 5, 120, 40);
        selectImageButton.setHorizontalAlignment(JButton.CENTER);
        selectImageButton.setVerticalAlignment(JButton.CENTER);
        selectImageButton.setForeground(Color.black);
        selectImageButton.setBackground(Color.yellow);
        this.add(selectImageButton);

        negative = new JButton("Negative");
        negative.addActionListener(e -> negativity());
        negative.setFocusable(false);
        negative.setBounds(615, 50, 120, 40);
        negative.setHorizontalAlignment(JButton.CENTER);
        negative.setVerticalAlignment(JButton.CENTER);
        negative.setForeground(Color.black);
        negative.setBackground(Color.yellow);
        this.add(negative);

        blackWhite = new JButton("blackWhite");
        blackWhite.addActionListener(e -> blackWhite());
        blackWhite.setFocusable(false);
        blackWhite.setBounds(615, 95, 120, 40);
        blackWhite.setHorizontalAlignment(JButton.CENTER);
        blackWhite.setVerticalAlignment(JButton.CENTER);
        blackWhite.setForeground(Color.black);
        blackWhite.setBackground(Color.yellow);
        this.add(blackWhite);

        grayScale = new JButton("grayScale");
        grayScale.addActionListener(e -> grayScale());
        grayScale.setFocusable(false);
        grayScale.setBounds(615, 140, 120, 40);
        grayScale.setHorizontalAlignment(JButton.CENTER);
        grayScale.setVerticalAlignment(JButton.CENTER);
        grayScale.setForeground(Color.black);
        grayScale.setBackground(Color.yellow);
        this.add(grayScale);

        shiftRight = new JButton("shiftRight");
        shiftRight.addActionListener(e -> shiftRight());
        shiftRight.setFocusable(false);
        shiftRight.setBounds(615, 185, 120, 40);
        shiftRight.setHorizontalAlignment(JButton.CENTER);
        shiftRight.setVerticalAlignment(JButton.CENTER);
        shiftRight.setForeground(Color.black);
        shiftRight.setBackground(Color.yellow);
        this.add(shiftRight);

        shiftLeft = new JButton("shiftLeft");
        shiftLeft.addActionListener(e -> shiftLeft());
        shiftLeft.setFocusable(false);
        shiftLeft.setBounds(615, 230, 120, 40);
        shiftLeft.setHorizontalAlignment(JButton.CENTER);
        shiftLeft.setVerticalAlignment(JButton.CENTER);
        shiftLeft.setForeground(Color.black);
        shiftLeft.setBackground(Color.yellow);
        this.add(shiftLeft);

        mirror = new JButton("mirror");
        mirror.addActionListener(e -> mirror());
        mirror.setFocusable(false);
        mirror.setBounds(615, 275, 120, 40);
        mirror.setHorizontalAlignment(JButton.CENTER);
        mirror.setVerticalAlignment(JButton.CENTER);
        mirror.setForeground(Color.black);
        mirror.setBackground(Color.yellow);
        this.add(mirror);

        Darker = new JButton("Darker");
        Darker.addActionListener(e -> Darker());
        Darker.setFocusable(false);
        Darker.setBounds(615, 320, 120, 40);
        Darker.setHorizontalAlignment(JButton.CENTER);
        Darker.setVerticalAlignment(JButton.CENTER);
        Darker.setForeground(Color.black);
        Darker.setBackground(Color.yellow);
        this.add(Darker);

        Lighter = new JButton("Lighter");
        Lighter.addActionListener(e -> Lighter());
        Lighter.setFocusable(false);
        Lighter.setBounds(615, 365, 120, 40);
        Lighter.setHorizontalAlignment(JButton.CENTER);
        Lighter.setVerticalAlignment(JButton.CENTER);
        Lighter.setForeground(Color.black);
        Lighter.setBackground(Color.yellow);
        this.add(Lighter);

        PixelAte = new JButton("PixelAte");
        PixelAte.addActionListener(e -> pixelate());
        PixelAte.setFocusable(false);
        PixelAte.setBounds(615, 410, 120, 40);
        PixelAte.setHorizontalAlignment(JButton.CENTER);
        PixelAte.setVerticalAlignment(JButton.CENTER);
        PixelAte.setForeground(Color.black);
        PixelAte.setBackground(Color.yellow);
        this.add(PixelAte);

        this.points = new Point[4];
        this.border = false;
        this.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (point < 4) {
                    if (e.getX() < (int) (selectedImage.getWidth() / max * 550) && e.getY() < (int) (selectedImage.getHeight() / max * 550)) {
                        Point temp_point = new Point(e.getX(), e.getY());
                        points[point++] = temp_point;
                    }
                }
                if (point == 4) {
                    border = true;
                }
                repaint();
            }


            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        });
    }

    private void selectImage() {
        fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select an Image");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif", "bmp"));
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                selectedImage = ImageIO.read(selectedFile);
                repaint();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }

    private void negativity() {
        if (selectedImage != null) {
            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    int negativeRed = 255 - current.getRed();
                    int negativeGreen = 255 - current.getGreen();
                    int negativeBlue = 255 - current.getBlue();
                    Color updated = new Color(negativeRed, negativeGreen, negativeBlue);
                    selectedImage.setRGB(x, y, updated.getRGB());
                    repaint();
                }
            }
        }
    }

    private void blackWhite() {
        Color updated;
        int Red, Green, Blue, avg;
        if (selectedImage != null) {
            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    Red = current.getRed();
                    Green = current.getGreen();
                    Blue = current.getBlue();
                    avg = (Red + Green + Blue) / 3;
                    if (avg > 128)
                        updated = new Color(255, 255, 255);
                    else
                        updated = new Color(0, 0, 0);
                    selectedImage.setRGB(x, y, updated.getRGB());
                    repaint();
                }
            }
        }
    }

    private void grayScale() {
        Color updated;
        int Red, Green, Blue, avg;
        if (selectedImage != null) {
            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    Red = current.getRed();
                    Green = current.getGreen();
                    Blue = current.getBlue();
                    avg = (Red + Green + Blue) / 3;
                    updated = new Color(avg, avg, avg);
                    selectedImage.setRGB(x, y, updated.getRGB());
                    repaint();
                }
            }
        }
    }

    private void shiftRight() {
        Color updated;
        int Red, Green, Blue;
        if (selectedImage != null) {
            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    Red = current.getRed();
                    Green = current.getGreen();
                    Blue = current.getBlue();
                    updated = new Color(Green, Blue, Red);
                    selectedImage.setRGB(x, y, updated.getRGB());
                    repaint();
                }
            }
        }
    }

    private void shiftLeft() {
        Color updated;
        int Red, Green, Blue;
        if (selectedImage != null) {
            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    Red = current.getRed();
                    Green = current.getGreen();
                    Blue = current.getBlue();
                    updated = new Color(Blue, Red, Green);
                    selectedImage.setRGB(x, y, updated.getRGB());
                    repaint();
                }
            }
        }
    }

    private void mirror() {
        if (selectedImage != null) {
            for (int x = minX; x < minX + (maxX - minX) / 2; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    Color mirrorCurrent = new Color(selectedImage.getRGB(maxX - x - 1 + minX, y));
                    selectedImage.setRGB(x, y, mirrorCurrent.getRGB());
                    selectedImage.setRGB(maxX - x - 1 + minX, y, current.getRGB());
                    repaint();
                }
            }
        }
    }

    private void pixelate() {
        int pixelSize = 10; // Size of each pixel block
        if (selectedImage != null) {
            for (int x = minX; x < maxX; x += pixelSize) {
                for (int y = minY; y < maxY; y += pixelSize) {
                    int rgb = selectedImage.getRGB(x, y);
                    for (int dy = 0; dy < pixelSize; dy++) {
                        for (int dx = 0; dx < pixelSize; dx++) {
                            if (x + dx < maxX && y + dy < maxY) {
                                selectedImage.setRGB(x + dx, y + dy, rgb);
                                repaint();
                            }
                        }
                    }
                }
            }
        }
    }

    private void Darker() {
        int Red, Green, Blue;
        if (selectedImage != null) {
            double rate = -2;
            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    Red = current.getRed();
                    Green = current.getGreen();
                    Blue = current.getBlue();
                    if (Red > 3 && Green > 3 && Blue > 3) {
                        Red = (int) (current.getRed() + rate);
                        Green = (int) (current.getGreen() + rate);
                        Blue = (int) (current.getBlue() + rate);
                    }
                    Color updated = new Color(Red, Green, Blue);
                    selectedImage.setRGB(x, y, updated.getRGB());
                    repaint();
                }
            }
        }
    }

    private void Lighter() {
        int Red, Green, Blue;
        if (selectedImage != null) {
            double rate = 2;
            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    Color current = new Color(selectedImage.getRGB(x, y));
                    Red = current.getRed();
                    Green = current.getGreen();
                    Blue = current.getBlue();
                    if (Red <253 && Green < 253 && Blue < 253) {
                        Red = (int) (current.getRed() + rate);
                        Green = (int) (current.getGreen() + rate);
                        Blue = (int) (current.getBlue() + rate);
                    }
                    if (Red > 255) {
                        Red = 255;
                    }
                    if (Green > 255) {
                        Green = 255;
                    }
                    if (Blue > 255) {
                        Blue = 255;
                    }
                    Color updated = new Color(Red, Green, Blue);
                    selectedImage.setRGB(x, y, updated.getRGB());
                    repaint();
                }
            }
        }
    }

    private Rectangle getSelectionRectangle() {
        minX = Math.min(Math.min(points[0].getX(), points[1].getX()), Math.min(points[2].getX(), points[3].getX()));
        minY = Math.min(Math.min(points[0].getY(), points[1].getY()), Math.min(points[2].getY(), points[3].getY()));
        maxX = Math.max(Math.max(points[0].getX(), points[1].getX()), Math.max(points[2].getX(), points[3].getX()));
        maxY = Math.max(Math.max(points[0].getY(), points[1].getY()), Math.max(points[2].getY(), points[3].getY()));

        minX = (int) (minX * max / 550);
        maxX = (int) (maxX * max / 550);
        minY = (int) (minY * max / 550);
        maxY = (int) (maxY * max / 550);
        return new Rectangle((int) (minX / max * 550), (int) (minY / max * 550), (int) (maxX / max * 550) - (int) (minX / max * 550), (int) (maxY / max * 550) - (int) (minY / max * 550));
    }


    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D graphics2D = (Graphics2D) graphics;
        if (selectedImage != null) {
            max = Math.max(selectedImage.getHeight(), selectedImage.getWidth());
            graphics2D.drawImage(selectedImage, 0, 0, (int) (selectedImage.getWidth() / max * 550), (int) (selectedImage.getHeight() / max * 550), this);

            if (point > 0 && !border) {
                for (int i = 0; i < point; i++) {
                    points[i].paint(graphics);
                }
            }
            if (border) {
                Rectangle selection = getSelectionRectangle();
                graphics.drawRect(selection.x, selection.y, selection.width, selection.height);
                border = false;
                point = 0;
            }
        }

    }
}