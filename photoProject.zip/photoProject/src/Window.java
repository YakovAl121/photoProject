import javax.swing.*;
public class Window extends JFrame {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;

    public Window() {
        this.setSize(WIDTH, HEIGHT);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        Background background = new Background(0,0,800,600);
        this.add(background);

    }


}